import { Button } from "@/components/ui/button";
import { AnimateOnScroll } from "@/components/AnimateOnScroll";
import { Instagram } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import breathingPattern from "@/assets/breathing-pattern.png";

const Index = () => {
  return (
    <main className="min-h-screen bg-background overflow-hidden">
      {/* Hero Section */}
      <HeroSection />

      {/* Supporting Line */}
      <SupportingLine />

      {/* How It Works */}
      <HowItWorks />

      {/* Trusted & Featured */}
      <TrustedSection />

      {/* Benefits */}
      <BenefitsSection />

      {/* When & How to Use */}
      <UsageSection />

      {/* Trust / Reassurance */}
      <ReassuranceSection />

      {/* Final CTA */}
      <FinalCTA />

      {/* Footer */}
      <Footer />
    </main>
  );
};

const HeroSection = () => {
  return (
    <header className="relative min-h-screen flex items-center justify-center section-padding overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40"
        style={{ backgroundImage: `url(${heroBg})` }}
        aria-hidden="true"
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" aria-hidden="true" />

      {/* Breathing Pattern Decorative Element */}
      <div className="absolute right-0 top-1/4 w-[500px] h-[500px] opacity-10 pointer-events-none" aria-hidden="true">
        <img src={breathingPattern} alt="" className="w-full h-full object-contain breathe" />
      </div>

      <div className="relative z-10 container mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Text Content */}
          <div className="glass-card-metallic p-8 md:p-12 animate-fade-in-up">
            {/* Logo Badge */}
            <div className="mb-8">
              <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-secondary/50 border border-metallic-border backdrop-blur-sm">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-glow">
                  <span className="text-primary-foreground text-xs font-bold">M</span>
                </div>
                <span className="text-sm font-medium text-foreground/80">MindOfDevice</span>
              </div>
            </div>

            <h1 className="text-3xl md:text-4xl lg:text-5xl font-medium text-foreground leading-tight mb-6 text-balance">
              a mind-off device which calms your mind within a minute
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
              a wearable device which will relax your mind based on your breathing
            </p>

            <div className="space-y-4">
              <Button variant="hero" size="xl" className="w-full sm:w-auto">
                Experience MindOfDevice
              </Button>
              
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-primary/60" aria-hidden="true" />
                Trusted by 1000+ people
              </p>
            </div>
          </div>

          {/* Device Image Area */}
          <div className="relative flex justify-center lg:justify-end animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="relative">
              {/* Glow Effect Behind Device */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent rounded-full blur-3xl scale-150 animate-pulse-glow" aria-hidden="true" />
              
              {/* Device Card */}
              <div className="relative glass-card-metallic p-8 rounded-3xl float">
                <div className="w-64 h-80 md:w-80 md:h-96 rounded-2xl bg-gradient-to-br from-secondary via-secondary/80 to-accent/50 flex items-center justify-center overflow-hidden">
                  {/* Breathing pattern overlay */}
                  <div className="absolute inset-0 opacity-20" aria-hidden="true">
                    <img src={breathingPattern} alt="" className="w-full h-full object-cover breathe" />
                  </div>
                  <div className="relative text-center p-6">
                    <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-glow animate-pulse-glow">
                      <span className="text-primary-foreground text-2xl font-bold">M</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Device Image Placeholder</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Replace with uploaded asset</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

const SupportingLine = () => {
  return (
    <section className="py-12 px-6" aria-label="Supporting message">
      <div className="container mx-auto max-w-4xl text-center">
        <AnimateOnScroll>
          <div className="glass-card p-8">
            <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed">
              calm your mind within minutes and you will be back track back on track to the
            </p>
          </div>
        </AnimateOnScroll>
      </div>
    </section>
  );
};

const HowItWorks = () => {
  const steps = [
    {
      number: "01",
      title: "Wear and Set",
    },
    {
      number: "02",
      title: "Mind Calming Starts",
    },
    {
      number: "03",
      title: "Mindfulness Filling Relief in Minutes",
    },
  ];

  return (
    <section className="section-padding" aria-labelledby="how-it-works-heading">
      <div className="container mx-auto max-w-6xl">
        <AnimateOnScroll>
          <h2 id="how-it-works-heading" className="text-2xl md:text-3xl font-medium text-center text-foreground mb-16">
            How It Works
          </h2>
        </AnimateOnScroll>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <AnimateOnScroll key={step.number} delay={index * 100}>
              <article className="glass-card-metallic p-8 text-center h-full">
                {/* Step Number */}
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 mb-6">
                  <span className="text-2xl font-medium text-primary">{step.number}</span>
                </div>

                <h3 className="text-xl font-medium text-foreground mb-4">{step.title}</h3>
                
                {/* Step Image Placeholder */}
                <div className="w-full h-32 rounded-xl bg-gradient-to-br from-secondary/50 to-accent/30 flex items-center justify-center overflow-hidden relative">
                  <div className="absolute inset-0 opacity-30" aria-hidden="true">
                    <img src={breathingPattern} alt="" className="w-full h-full object-cover" />
                  </div>
                  <span className="relative text-xs text-muted-foreground">Step Image</span>
                </div>
              </article>
            </AnimateOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
};

const TrustedSection = () => {
  const mediaLogos = ["TV News", "Radio", "Digital Media", "Wellness Platforms"];

  return (
    <section className="section-padding bg-gradient-to-b from-transparent via-secondary/10 to-transparent" aria-labelledby="trusted-heading">
      <div className="container mx-auto max-w-6xl">
        <AnimateOnScroll>
          <div className="glass-card-metallic p-8 md:p-12 text-center">
            <h2 id="trusted-heading" className="text-2xl md:text-3xl font-medium text-foreground mb-4">
              Trusted by People. Featured by Media
            </h2>
            
            <p className="text-lg text-muted-foreground mb-12">
              Trusted by people. Featured across media.
            </p>

            {/* Media Logos */}
            <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-8">
              {mediaLogos.map((logo) => (
                <div
                  key={logo}
                  className="px-6 md:px-8 py-4 rounded-xl bg-gradient-to-br from-secondary/60 to-secondary/30 border border-metallic-border backdrop-blur-sm"
                >
                  <span className="text-sm font-medium text-muted-foreground">{logo}</span>
                </div>
              ))}
            </div>

            {/* Metallic Divider */}
            <div className="w-32 h-px mx-auto bg-gradient-to-r from-transparent via-border to-transparent mb-6" aria-hidden="true" />

            <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary/60" aria-hidden="true" />
              Trusted by 1000+ people
            </p>
          </div>
        </AnimateOnScroll>
      </div>
    </section>
  );
};

const BenefitsSection = () => {
  const benefits = [
    "reduces stress anxiety",
    "controls overthinking",
    "helps calm your mind",
    "supports better sleep",
    "improves focus and mental clarity",
    "automatic meditation",
  ];

  return (
    <section className="section-padding" aria-labelledby="benefits-heading">
      <div className="container mx-auto max-w-5xl">
        <AnimateOnScroll>
          <h2 id="benefits-heading" className="text-2xl md:text-3xl font-medium text-center text-foreground mb-16">
            Benefits
          </h2>
        </AnimateOnScroll>

        <div className="flex flex-wrap justify-center gap-4">
          {benefits.map((benefit, index) => (
            <AnimateOnScroll key={benefit} delay={index * 80}>
              <div className="pill-card">
                {/* Orange Accent Dot */}
                <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-br from-primary to-primary/70 flex-shrink-0 shadow-[0_0_8px_hsl(24_100%_50%/0.4)]" aria-hidden="true" />
                <span className="text-foreground font-medium">{benefit}</span>
              </div>
            </AnimateOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
};

const UsageSection = () => {
  return (
    <section className="section-padding bg-gradient-to-b from-secondary/10 via-secondary/20 to-secondary/10" aria-labelledby="usage-heading">
      <div className="container mx-auto max-w-5xl">
        <AnimateOnScroll>
          <h2 id="usage-heading" className="text-2xl md:text-3xl font-medium text-center text-foreground mb-16">
            When & How to Use
          </h2>
        </AnimateOnScroll>

        <AnimateOnScroll delay={100}>
          <div className="glass-card-metallic p-8 md:p-12">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <p className="text-lg text-foreground leading-relaxed">
                  you can use three times in a day.
                </p>
                <p className="text-lg text-foreground leading-relaxed">
                  you can use it in morning, afternoon, and evening.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  just find a peaceful place, make sure that we'll be having no noise at all. You can just find a comfortable place to sit and just plug in the device, play the music which will be given to you, and this will start to the mindfulness, calming your or relieving your mind.
                </p>
              </div>

              {/* Usage Image/Video Placeholder */}
              <div className="w-full h-64 lg:h-80 rounded-2xl bg-gradient-to-br from-secondary/60 to-accent/40 flex items-center justify-center overflow-hidden relative">
                <div className="absolute inset-0 opacity-30" aria-hidden="true">
                  <img src={breathingPattern} alt="" className="w-full h-full object-cover breathe" />
                </div>
                <span className="relative text-sm text-muted-foreground">Usage Video Placeholder</span>
              </div>
            </div>
          </div>
        </AnimateOnScroll>
      </div>
    </section>
  );
};

const ReassuranceSection = () => {
  return (
    <section className="section-padding" aria-labelledby="reassurance-heading">
      <div className="container mx-auto max-w-4xl">
        <AnimateOnScroll>
          <div className="glass-card p-8 md:p-16 text-center relative overflow-hidden">
            {/* Background decoration */}
            <div className="absolute inset-0 opacity-5" aria-hidden="true">
              <img src={breathingPattern} alt="" className="w-full h-full object-cover" />
            </div>
            
            {/* Trust Icon */}
            <div className="relative w-16 h-16 mx-auto mb-8 rounded-full bg-gradient-to-br from-primary/15 to-primary/5 border border-primary/20 flex items-center justify-center">
              <svg className="w-8 h-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>

            <h2 id="reassurance-heading" className="sr-only">Safety and Reassurance</h2>
            <p className="relative text-xl md:text-2xl text-foreground leading-relaxed font-light">
              It is nothing like the medical fear, complexity, or risk, because this product completely depends on your breathing only. You just have to listen it, and just feel it, and focus on your breathing, that's it.
            </p>
          </div>
        </AnimateOnScroll>
      </div>
    </section>
  );
};

const FinalCTA = () => {
  return (
    <section className="section-padding relative" aria-label="Call to action">
      {/* Background glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden="true">
        <div className="w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
      </div>
      
      <div className="relative container mx-auto max-w-3xl text-center">
        <AnimateOnScroll>
          <Button variant="hero" size="xl" className="animate-pulse-glow">
            Experience MindOfDevice
          </Button>
        </AnimateOnScroll>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 px-6 border-t border-border/30">
      <div className="container mx-auto max-w-6xl">
        <div className="glass-card p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            © MindOfDevice
          </p>

          {/* Social / Instagram */}
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 px-5 py-2.5 rounded-full bg-gradient-to-br from-secondary/60 to-secondary/30 border border-metallic-border hover:from-secondary/80 hover:to-secondary/50 transition-all duration-300 hover:-translate-y-0.5"
            aria-label="Follow us on Instagram"
          >
            <Instagram className="w-5 h-5 text-foreground" aria-hidden="true" />
            <span className="text-sm text-foreground">Follow us</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Index;
